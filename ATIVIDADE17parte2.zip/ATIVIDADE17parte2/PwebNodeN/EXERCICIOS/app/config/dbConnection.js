
var sql = require ('mssql');

module.exports = function () {
    const sqlConfig = {
        user: 'BD2213',
        password: '',
        database: 'BD',
        server: 'APOLO',
        options: {
            encrypt: false,
            trustServerCertificate: true,
        }
    }
    return sql.connect(sqlConfig);
}

