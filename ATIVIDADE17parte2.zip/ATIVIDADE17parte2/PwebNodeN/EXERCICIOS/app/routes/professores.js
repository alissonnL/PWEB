var dbConnection = require('../config/dbConnection');

module.exports = function(app){
    app.get('/informacao/professores', function(req,res){
        //res.end("<html><body>Professores da Fatec Sorocaba</body></html>")
            async function getProfessores(){
                try{
                    const pool = await dbConnection() //executando a função;
                    const results = await pool.request().query('SELECT * from PROFESSORES');
                    res.render('informacao/professores',{profs: results.recordset});
                }catch(err){
                    console.log(err);
                }
                //res.render('informacao/professores');
            }

            getProfessores();
            });
        
}

